
var countChecked = function() {
    var n = $('input:checkbox[name="individual"]:checked').length;
    

    if(n==1){
      $("#btnconstanciaid").removeClass("btnconstancia");
      
    }else if(n==0){
      $("#btnconstanciaid").addClass("btnconstancia");
    
    }

    $( "#contador" ).text( n + (n === 1 ? " seleccionado" :" seleccionados") );

   
  };
  countChecked();
   
  $( 'input:checkbox[name="individual"]' ).on( "click", countChecked );

$('#all').change(function () {
    if($(this).prop('checked') == true) {
        var ele=document.getElementsByName('individual');  
        for(var i=0; i<ele.length; i++){  
            if(ele[i].type=='checkbox')  
                ele[i].checked=true;  
        }  
        var n = ele.length;

          $("#btnconstanciaid").removeClass("btnconstancia");
          


        $( "#contador" ).text( n + (n === 1 ? " seleccionado" :" seleccionados") );
  }else {
    var ele=document.getElementsByName('individual');  
    for(var i=0; i<ele.length; i++){  
        if(ele[i].type=='checkbox')  
            ele[i].checked=false;  
          
    } 
    $("#btnconstanciaid").addClass("btnconstancia");
    var n = 0;
    $( "#contador" ).text( n + (n === 1 ? " seleccionado" :" seleccionados") );
  }

});  


  $(document).on('click','#btngenerar',function(){


  let checkboxes = document.querySelectorAll('input[name="individual"]:checked');
  let output = [];
  checkboxes.forEach((checkbox) => {
      output.push(checkbox.value);
  });

  $.ajax({
    type: "POST",
    url: 'generar_constancias.php',
    data: {'array': output},//capturo array   JSON.stringify(  
    success: function(data){
     // alert(data);
  }
});
 // $('#recipient_id').val(output);

});
